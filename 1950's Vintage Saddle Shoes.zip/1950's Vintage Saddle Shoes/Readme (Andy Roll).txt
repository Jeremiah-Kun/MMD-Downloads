Rules:

- You don't have to credit me. Just credit FoxyLuka777
- Do not claim as yours
- Do not use for commercial purposes
- Do not use in AnastasiaP BATIM's Motions
- Do not redistribute the original item
- It's under your responsibility if R-18/NC-17/Fetish
- Exclusively redistribute on a finished model
- Do not use this part to represent hateful content
- Do not use this part for model and/or outfit downloads without my written permission.

Anyone who breaks these rules will be blocked and restricted from future access.

Me and FoxyLuka777 are not responsible for the damage caused by this type of MMD content.

Note: NOTE: I certainly did not make these shoes. This part is made by FoxyLuka777 from my commission and I recommend you credit him for making this part.

- Regards,
Jeremiah D. Blake (Andy Barnabas Roll)